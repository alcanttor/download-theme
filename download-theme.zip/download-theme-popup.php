<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="dtwap-modal-view">

    <div class="dtwap-modal-overlay dtwap-popup-overlay-fade-in"></div>

    <div class="dtwap-modal-wrap dtwap-popup-out">
           <button class="dtwap-modal-close dtwap-close-btn " type="button" >&#10005;</button>
        <div class="dtwap_section_first-slide dpwap_section_content current">
            <div class="dtwap_row dtwap__head_row">
                 <div class="dpwap-head-img">
                            <img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/slide-1.png'; ?>">
                        </div>

            </div> 

            <div class="dtwap__head_body">

                <div class="dtwap_row">
                    <div class="dtwap_slide_head dtwap-section-col">
                   Thank you for installing Download theme!
                    </div>
                </div>

                <div class="dtwap_row">
                    <div class="dtwap-section-col">
                        It is now awfully easy to download any theme from your website dashboard with a single click! <a href="themes.php">Try it now</a>.
                    </div>
                </div>

                <div class="dtwap_modal_footer">

                    <button class="btn btn-default next-tab dtwap-modal-close" id="second-slide-button" type="button">Close</button>
                </div>


            </div>

        </div>

    </div>

</div>